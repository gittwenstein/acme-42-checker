#include <assert.h>

void ft_putchar(char c);

int main()
{
	char letter = 'Q';
	ft_putchar(letter);
}