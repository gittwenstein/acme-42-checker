void ft_print_alphabet(void);

int main()
{
	ft_print_alphabet();	
}