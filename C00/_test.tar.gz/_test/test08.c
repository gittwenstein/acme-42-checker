#include <stdlib.h>

void ft_print_combn(int n);

int	main(int argc, char **argv)
{
	ft_print_combn(atoi(argv[1]));
}