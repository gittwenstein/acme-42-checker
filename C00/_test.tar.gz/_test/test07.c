#include <stdlib.h>

void ft_putnbr(int nb);

int main(int count, char **args) 
{
	ft_putnbr(atoi(args[1]));
}

