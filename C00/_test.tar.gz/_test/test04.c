#include <stdlib.h>

void ft_is_negative(int n);

int main(int count, char **args)
{
	ft_is_negative(atoi(args[1]));
}
