void ft_print_reverse_alphabet(void);

int main()
{
	ft_print_reverse_alphabet();	
}