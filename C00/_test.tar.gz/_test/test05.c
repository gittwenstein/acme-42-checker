#include <assert.h>

void ft_print_comb(void);

int main(void)
{
	ft_print_comb();
}