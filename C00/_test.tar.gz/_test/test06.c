#include <assert.h>

void ft_print_comb2(void);

int main(void)
{
	ft_print_comb2();
}