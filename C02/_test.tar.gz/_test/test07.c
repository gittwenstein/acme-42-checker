#include <assert.h>
#include <stdlib.h>
#include <string.h>

char *ft_strupcase(char *str);

int main(int count, char **args)
{
	assert
	(
		strcmp(ft_strupcase(args[1]), args[2]) == 0
	);
}
