#include <assert.h>
#include <stdlib.h>
#include <string.h>

char *ft_strlowcase(char *str);

int main(int count, char **args)
{
	assert
	(
		strcmp(ft_strlowcase(args[1]), args[2]) == 0
	);
}
