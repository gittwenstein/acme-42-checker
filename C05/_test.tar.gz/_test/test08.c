#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int ft_ten_queens_puzzle(void);

int main(int count, char **args)
{
	assert(ft_ten_queens_puzzle() == 724);
}