#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

void ft_putstr(char *str);

int main(int count, char **args)
{
	ft_putstr(args[1]);
}