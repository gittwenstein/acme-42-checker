#include <assert.h>

void ft_putstr(char *str);

int main(int count, char **args)
{
	ft_putstr(args[1]);
}